# File name: dptsd.R
# estimate dynamic panel threshold spaial model with one threshold

# Some useful functions: compute OLS estimates
reg <- function(X,y) {
  X <- qr(X)
  as.matrix(qr.coef(X,y))
}



tr <- function (y, tt, n)
{
  yf <- matrix(y, nrow = tt, ncol = n)
  #for (i in 1:n) {
  #  yf[i, ] <- y[(1 + (i - 1) * tt):(tt * i)]
  #}
  yf2 <- t(yf)
  yfm <- yf2 - colMeans(yf)
  #yfm <- yfm[, 1:(tt - 1)]
  out <- matrix(t(yfm), nrow = nrow(yfm) * ncol(yfm), ncol = 1)
  out
}



tr2 <- function (y, tt, n)
{
  yf <- matrix(0, nrow = n, ncol = tt)
  for (i in 1:n) {
    yf[i, ] <- y[(1 + (i - 1) * tt):(tt * i)]
  }
  yfm <- yf - colMeans(t(yf))
  #yfm <- yfm[, 1:(tt - 1)]
  out <- matrix(t(yfm), nrow = nrow(yfm) * ncol(yfm), ncol = 1)
  out
}


fe <- function (e, tt, n) {
  ef <- matrix(e, nrow = tt, ncol = n)

  efm <-  matrix(0, nrow = n, ncol = tt)+ colMeans(ef)
  out <- matrix(t(efm), nrow = nrow(efm) * ncol(efm), ncol = 1)
  out
}


eboot <- function(et,tt,n){
  etm <- matrix(et,tt,n)
  nc <- sample(n,n,replace = T)
  etm2 <- etm[,nc]
  eboot <- as.vector(etm2)
  eboot
}



#-------------------------------------------
#c_i
getmi = function(x,tt,nn){
  k = ncol(x)
  z1 = matrix(as.vector(matrix(colMeans(matrix(as.vector(x),nrow = tt)),nrow = tt,ncol = nn*k,byrow = TRUE)),nrow = tt*nn,ncol = k)
  return(z1)
}


#f_t 
getmi2 = function(x,tt,nn){
  k = ncol(x)
  z1 = matrix(as.vector(matrix(rowMeans(matrix(as.vector(x),nrow = tt)),nrow = tt,ncol = nn*k,byrow = FALSE)),nrow = tt*nn,ncol = k)
  return(z1)
}


#-------------------------------------------
# linear
#cre+iv
dpsd_linear <- function(y,x, w,tt,n) {
  
  
  # Linear spatial Model
  
  
  #-------------------------------------------
  y_mat <- matrix(y,tt,n)
  y_mat1 <- matrix(NA,tt,n)
  y_mat1[2:t,] <- y_mat[1:(t-1),]
  y_1 <- as.vector(na.omit(y_mat1))
  y <- as.vector(y_mat[-1,])
  
  x_mat <- matrix(x,tt,n)
  x_mat1 <- matrix(NA,tt,n)
  x_mat1[2:t,] <- x_mat[1:(t-1),]
  x_1 <- as.vector(na.omit(x_mat1))
  x <- as.vector(x_mat[-1,])
  
  #-------------------------------------------
  tt = tt-1
  t=tt
  it = diag(tt)
  h = kronecker(w,it)
  h2 = h%*%h
  wy = h%*%y
  wx = h%*%x
  w2 = w%*%w
  wsqx = h2%*%x
  
  
  #sum/T means to control fixed effects c_i
  x = as.matrix(x)
  xbar = getmi(x,t,n)
  wx = as.matrix(wx)
  wxbar = getmi(wx,t,n)
  
  # initial values and constant 1
  y0 <- y_mat[1,]
  y0m = matrix(y0, nrow = t, ncol = n, byrow = TRUE)
  y0 = as.vector(y0m)
  z1 = matrix(1,nrow = n*t)
  #sum/N means for f_t
  xtsbar = getmi2(x,t,n)
  wxtsbar = getmi2(wx,t,n)
  ############################
  #interactive
  ci=cbind(xbar,wxbar,y0)
  ft=cbind(xtsbar,wxtsbar)
  #intercf = cbind(xbar*xtsbar,xbar*wxtsbar,wxbar*xtsbar,wxbar*wxtsbar,y0*xtsbar,y0*wxtsbar)
  
  a = cbind(diag(ci[,1]), diag(ci[,2]),diag(ci[,3]))
  b = kronecker(diag(3),ft)
  intercf = a %*% b
  
  #intercf = (xbar+wxbar+y0)*(xtsbar+wxtsbar)
  # another simple way with less variables but cannot obtain correct coeffs for augmented variables
  ############################
  #xz = cbind(y_1,wy1,wy,x,wx,xbar,wxbar,xtsbar,wxtsbar,intercf)
  
  
  iv = cbind(x, wx, wsqx, x_1, h%*%x_1, h2%*%x_1,ci,ft,intercf,z1)

  wythat = iv%*%reg(iv,wy)
  
  wy_1 = h%*%y_1
  wythat_1 = iv%*%reg(iv,wy_1)
  
  y1hat = iv%*%reg(iv,y_1)
  
  
  


  xall = cbind(y1hat,wythat_1,wythat,x,wx,xbar,wxbar,xtsbar,wxtsbar,intercf,z1,y0)
  blin = reg(xall, y)
  
  yhat_linear = xall%*%blin
  e = y - xall%*%blin
  ssr = sum(e^2)
  # x0 = xall
  # 
  # x00 = solve(crossprod(x0))  #inverse of x0'x0
  # bols = x00%*%crossprod(x0,yt)
  # 
  # ones<-matrix(1,t,t)
  # jbar<-ones/t
  # E<-diag(t)-jbar
  # P<-kronecker(diag(n),jbar)
  # Z<-cbind(y_1,h%*%y_1,h%*%y,x,h%*%x)
  # ieffct<-P%*%(y-Z%*%bols)
  # yhat<-Z%*%bols+ieffct
  # 
  # yhat_linear = yhat
  # res<-y-yhat
  # nt = length(yt)
  # sigols<-sum(res^2)/(nt-k-1)
  
  return(list(blin=blin,ssr=ssr,yhat_linear=yhat_linear))
}


#-------------------------------------------

#--------------------------------------------
#-------------------------------------------
# linear
#cre+iv without cf (interactive effects)
dpsd_linear_without_cf <- function(y,x, w,tt,n) {
  
  
  # Linear spatial Model
  
  
  #-------------------------------------------
  y_mat <- matrix(y,tt,n)
  y_mat1 <- matrix(NA,tt,n)
  y_mat1[2:t,] <- y_mat[1:(t-1),]
  y_1 <- as.vector(na.omit(y_mat1))
  y <- as.vector(y_mat[-1,])
  
  x_mat <- matrix(x,tt,n)
  x_mat1 <- matrix(NA,tt,n)
  x_mat1[2:t,] <- x_mat[1:(t-1),]
  x_1 <- as.vector(na.omit(x_mat1))
  x <- as.vector(x_mat[-1,])
  
  #-------------------------------------------
  tt = tt-1
  t=tt
  it = diag(tt)
  h = kronecker(w,it)
  h2 = h%*%h
  wy = h%*%y
  wx = h%*%x
  w2 = w%*%w
  wsqx = h2%*%x
  
  
  #sum/T means to control fixed effects c_i
  x = as.matrix(x)
  xbar = getmi(x,t,n)
  wx = as.matrix(wx)
  wxbar = getmi(wx,t,n)
  
  # initial values and constant 1
  y0 <- y_mat[1,]
  y0m = matrix(y0, nrow = t, ncol = n, byrow = TRUE)
  y0 = as.vector(y0m)
  z1 = matrix(1,nrow = n*t)
  #sum/N means for f_t
  xtsbar = getmi2(x,t,n)
  wxtsbar = getmi2(wx,t,n)
  ############################
  #interactive
  ci=cbind(xbar,wxbar,y0)
  ft=cbind(xtsbar,wxtsbar)
  #intercf = cbind(xbar*xtsbar,xbar*wxtsbar,wxbar*xtsbar,wxbar*wxtsbar,y0*xtsbar,y0*wxtsbar)
  

  

  
  
  iv = cbind(x, wx, wsqx, x_1, h%*%x_1, h2%*%x_1,ci,ft,z1)
  
  wythat = iv%*%reg(iv,wy)
  
  wy_1 = h%*%y_1
  wythat_1 = iv%*%reg(iv,wy_1)
  
  y1hat = iv%*%reg(iv,y_1)
  
  
  
  
  
  xall = cbind(y1hat,wythat_1,wythat,x,wx,xbar,wxbar,xtsbar,wxtsbar,z1)
  blin = reg(xall, y)
  
  e = y - xall%*%blin
  ssr = sum(e^2)
  yhat_linear = xall%*%blin
  
  return(list(blin=blin,ssr=ssr,yhat_linear=yhat_linear))
}





#--------------------------------------------
#-------------------------------------------
# linear
#cre+iv without c+f+ cf (random effects)
dpsd_linear_random <- function(y,x, w,tt,n) {
  
  
  # Linear spatial Model
  
  
  #-------------------------------------------
  y_mat <- matrix(y,tt,n)
  y_mat1 <- matrix(NA,tt,n)
  y_mat1[2:t,] <- y_mat[1:(t-1),]
  y_1 <- as.vector(na.omit(y_mat1))
  y <- as.vector(y_mat[-1,])
  
  x_mat <- matrix(x,tt,n)
  x_mat1 <- matrix(NA,tt,n)
  x_mat1[2:t,] <- x_mat[1:(t-1),]
  x_1 <- as.vector(na.omit(x_mat1))
  x <- as.vector(x_mat[-1,])
  
  #-------------------------------------------
  tt = tt-1
  t=tt
  it = diag(tt)
  h = kronecker(w,it)
  h2 = h%*%h
  wy = h%*%y
  wx = h%*%x
  w2 = w%*%w
  wsqx = h2%*%x
  
  
  #sum/T means to control fixed effects c_i
  x = as.matrix(x)
  xbar = getmi(x,t,n)
  wx = as.matrix(wx)
  wxbar = getmi(wx,t,n)
  
  # initial values and constant 1
  y0 <- y_mat[1,]
  y0m = matrix(y0, nrow = t, ncol = n, byrow = TRUE)
  y0 = as.vector(y0m)
  z1 = matrix(1,nrow = n*t)
  #sum/N means for f_t

  #intercf = cbind(xbar*xtsbar,xbar*wxtsbar,wxbar*xtsbar,wxbar*wxtsbar,y0*xtsbar,y0*wxtsbar)
  
  
  
  
  
  
  iv = cbind(x, wx, wsqx, x_1, h%*%x_1, h2%*%x_1,z1)
  
  wythat = iv%*%reg(iv,wy)
  
  wy_1 = h%*%y_1
  wythat_1 = iv%*%reg(iv,wy_1)
  
  y1hat = iv%*%reg(iv,y_1)
  
  
  
  
  
  xall = cbind(y1hat,wythat_1,wythat,x,wx,z1)
  blin = reg(xall, y)
  
  e = y - xall%*%blin
  ssr = sum(e^2)
  yhat_linear = xall%*%blin
  
  return(list(blin=blin,ssr=ssr,yhat_linear=yhat_linear))
}


##########################################################
# testing for interactive effects
testF1 <- function(y,x, w, n, t, boot=50,level=0.9) {

  # write a bootstrap for testing
  #############################################################
  #step 1 compute residuals of the linear model without interactive effs

  tt = t
  est_th <- dpsd_linear_without_cf(y,x, w,tt,n)
  yhat_linear <- est_th$yhat_linear
  
  est_linear <- dpsd_linear(y,x, w,tt,n)
  #############################################################
  y_mat <- matrix(y,tt,n)
  y_mat1 <- matrix(NA,tt,n)
  y_mat1[2:t,] <- y_mat[1:(t-1),]
  y_1 <- as.vector(na.omit(y_mat1))
  ys <- as.vector(y_mat[-1,])
  
  x_mat <- matrix(x,tt,n)
  x_mat1 <- matrix(NA,tt,n)
  x_mat1[2:t,] <- x_mat[1:(t-1),]
  x_1 <- as.vector(na.omit(x_mat1))
  xs <- as.vector(x_mat[-1,])
  
  
  res<-ys-yhat_linear
  
 
  Ftest=(est_th$ssr-est_linear$ssr)/(est_linear$ssr/length(ys))
  
  ##############################################################
  #step 2


  Fb = matrix(NA,boot)
  nt <- length(ys)
 

  for (j in 1:boot) {

    t <- nt/n
    uitx = as.vector(matrix(rnorm(n),nrow = t,ncol = n,byrow = TRUE))
    yb <- yhat_linear+res*uitx
    
    yb_mat <- matrix(yb,t,n)
    yb_0 <- y_mat[1,]
    yb <- as.vector(rbind(yb_0,yb_mat))
  

    
    t=tt

    est_thb <- dpsd_linear_without_cf(y=yb,x, w,tt,n)
    
    est_linearb <- dpsd_linear(y=yb,x, w,tt,n)
    te1 = (est_thb$ssr-est_linearb$ssr)/(est_linearb$ssr/length(ys))
    Fb[j]=te1
  }

  pv = mean(Fb > matrix(Ftest,boot,1))
  crit = quantile(Fb,probs=level)

  cat('sig. level    =', level, '\n')
  cat('critical value    =', crit, '\n')
  cat("----------------------------------------------","\n")
  cat("statistic(linear vs threshold)=", "\n")
  print(Ftest)
  cat('p-value   =', pv, '\n')
  cat("----------------------------------------------","\n")
  return(list(pv=pv, crit=crit))
}




##########################################################
# testing for random effects
testF2 <- function(y,x, w, n, t, boot=50,level=0.9) {
  
  # write a bootstrap for testing
  #############################################################
  #step 1 compute residuals of the linear model without interactive effs
  
  tt = t
  est_th <- dpsd_linear_random(y,x, w,tt,n)
  yhat_linear <- est_th$yhat_linear
  
  est_linear <- dpsd_linear(y,x, w,tt,n)
  #############################################################
  y_mat <- matrix(y,tt,n)
  y_mat1 <- matrix(NA,tt,n)
  y_mat1[2:t,] <- y_mat[1:(t-1),]
  y_1 <- as.vector(na.omit(y_mat1))
  ys <- as.vector(y_mat[-1,])
  
  x_mat <- matrix(x,tt,n)
  x_mat1 <- matrix(NA,tt,n)
  x_mat1[2:t,] <- x_mat[1:(t-1),]
  x_1 <- as.vector(na.omit(x_mat1))
  xs <- as.vector(x_mat[-1,])
  
  
  res<-ys-yhat_linear
  
  
  Ftest=(est_th$ssr-est_linear$ssr)/(est_linear$ssr/length(ys))
  
  ##############################################################
  #step 2
  
  
  Fb = matrix(NA,boot)
  nt <- length(ys)
  
  
  for (j in 1:boot) {
    
    t <- nt/n
    #uitx = as.vector(matrix(rnorm(n),nrow = t,ncol = n,byrow = TRUE))
    yb <- yhat_linear+res*rnorm(nt)
    
    yb_mat <- matrix(yb,t,n)
    yb_0 <- y_mat[1,]
    yb <- as.vector(rbind(yb_0,yb_mat))
    
    
    
    t=tt
    
    est_thb <- dpsd_linear_random(y=yb,x, w,tt,n)
    
    est_linearb <- dpsd_linear(y=yb,x, w,tt,n)
    te1 = (est_thb$ssr-est_linearb$ssr)/(est_linearb$ssr/length(ys))
    Fb[j]=te1
  }
  
  pv = mean(Fb > matrix(Ftest,boot,1))
  crit = quantile(Fb,probs=level)
  
  cat('sig. level    =', level, '\n')
  cat('critical value    =', crit, '\n')
  cat("----------------------------------------------","\n")
  cat("statistic(linear vs threshold)=", "\n")
  print(Ftest)
  cat('p-value   =', pv, '\n')
  cat("----------------------------------------------","\n")
  return(list(pv=pv, crit=crit))
}



