
rm(list=ls())
setwd("xx")
#source("dptsd_mcmc.R")
source("cre_dptsd.R")
source("cre_DGP_dynamic.R")
library("magrittr")

library("splm")
library("spatialreg")
library("SDPDmod")  #SDPDm for ml of lee and yu

pt1 = proc.time()
set.seed(123)

nrep=1000 #replications
estb <- matrix(rep(NA, 6 * nrep), ncol = 6)
estb_ml <- matrix(rep(NA, 6 * nrep), ncol = 6)
estb_gmm <- matrix(rep(NA, 6 * nrep), ncol = 6)
estb_mcmc <- matrix(rep(NA, 6 * nrep), ncol = 6)

for(rp in 1:nrep){
  
  data = dgp_0th(t=10,n=100)
  y <- data$y
  x <- data$x
  w <- data$w
  t <- data$t
  n <- data$n
  id <- data$id
  ye <- data$ye
  #tt =t
  #--------------------------------
  pt11 = proc.time()
  est_linear <- dpsd_linear(y,x, w,tt=t,n)
  est_linear$blin
  pt12 = proc.time()
  
  estb[rp,]=c(est_linear$blin[1:5],pt12[3]-pt11[3])
  
  ############################################
  ##ML of Lee and Yu
  pt21 = proc.time()
  form1 <- y ~ x
  mod2  <- SDPDm(formula = form1, data = data.frame(id,ye,y,x),  W = w, index = c("id","ye"),
                 model = "sdm", effect = "twoways", LYtrans = FALSE,
                 dynamic = TRUE, tlaginfo=list(ind = NULL, tl = TRUE, stl = TRUE))
  bml <- mod2$coefficients
  mod2$rho #wy
  pt22 = proc.time()
  estb_ml[rp,]=c(bml[1:2],mod2$rho,bml[3:4],pt22[3]-pt21[3])
  
  
  
  #GMM
  pt31 = proc.time()
  library(GMMSPT) #local package
  d0 = data
  m0 <- dpsd_linear_new(y=d0$y,x=as.matrix(d0$x),w=d0$w,tt=d0$t,n=d0$n)####x 和s必须为矩阵
  m0$coefs
  pt32 = proc.time()
  estb_gmm[rp,]=c(m0$coefs,pt32[3]-pt31[3])
  # rm(list=ls())
  # source("DPTSDCDT.R")
  # Rcpp::sourceCpp("roptimPack.cpp")
  # library(magrittr)
  # data <- DGP(n=100,t=11,model = c('Linear'))
  # yy <- data$Y
  # xx <- data$X
  # ww <- data$W
  # n=100
  # t=11
  # ym <- matrix(y,nrow = n,ncol = t)
  # xm <- matrix(x,nrow = n,ncol = t)
  # DPTSD_Linear(Y=ym,X=xm,W=w)
  pt41 = proc.time()
  est_mcmc <- dpsd_mcmc(y,x, w,tt=t,n,ms=20000,burnin=10000) 
  est_mcmc$blin
  pt42 = proc.time()
  estb_mcmc[rp,]=c(est_mcmc$blin,pt42[3]-pt41[3])
  
}


mi1=colMeans(estb)
sd1=cbind(sd(estb[,1]),sd(estb[,2]),sd(estb[,3]),sd(estb[,4]),sd(estb[,5]),sd(estb[,6]))
mi_cre <- mi1
#md=cbind(mi1[1],sd(estb[,1]),mi1[2],sd(estb[,2]),mi1[3],sd(estb[,3]),mi1[4],sd(estb[,4]),mi1[5],sd(estb[,5]))


mi_ml=colMeans(estb_ml)
sd2=cbind(sd(estb_ml[,1]),sd(estb_ml[,2]),sd(estb_ml[,3]),sd(estb_ml[,4]),sd(estb_ml[,5]),sd(estb_ml[,6]))

mi_gmm=colMeans(estb_gmm)
sd3=cbind(sd(estb_gmm[,1]),sd(estb_gmm[,2]),sd(estb_gmm[,3]),sd(estb_gmm[,4]),sd(estb_gmm[,5]),sd(estb_gmm[,6]))

mi_mcmc=colMeans(estb_mcmc)
sd4=cbind(sd(estb_mcmc[,1]),sd(estb_mcmc[,2]),sd(estb_mcmc[,3]),sd(estb_mcmc[,4]),sd(estb_mcmc[,5]),sd(estb_mcmc[,6]))

######################


rbind(mi_cre,sd1)
rbind(mi_ml,sd2)
rbind(mi_gmm,sd3)
rbind(mi_mcmc,sd4)

pt2 = proc.time()

print(c(nrep,pt2[3]-pt1[3]),digits=3)
Sys.time()

save.image("comparing CRE with others.RData")
# sink(paste("Table 1 cer simulation results.txt"))
# cat("Table 1","\n")
# md
# sink()


###############################################################
#figure for bias
#load("comparing CRE without interactive eff.RData")
com_data1 <- cbind(mi_cre[1:5],mi_ml[1:5],mi_gmm[1:5],mi_mcmc[1:5])
com_data <- abs(com_data1-c(0.3,-0.6,0.3,1,1))
rownames(com_data)=c("rho","lambda","alpha","beta","theta")
colnames(com_data)=c("CRE","ML","GMM","MCMC")
library(ggplot2)
library(reshape2)
library(dplyr)
data_rownames <- rownames(com_data)
data_colnames <- colnames(com_data)
id.var <- data_rownames
data_m <- melt(com_data,id=id.var)
data_m$idv <- seq(1, 20, by = 1)
data_m

colnames(data_m)=c("parameters","methods","bias","id")
data_m

p <- ggplot(data_m,aes(x=parameters,y=bias))
p2 <- p+geom_bar(stat = "identity",position = "dodge",aes(fill=methods))
p2+theme(legend.position="top")


###############################################################
#figure for rmse
#load("comparing CRE without interactive eff.RData")
com_data <- cbind(sd1[1:5],sd2[1:5],sd3[1:5],sd4[1:5])
rownames(com_data)=c("rho","lambda","alpha","beta","theta")
colnames(com_data)=c("CRE","ML","GMM","MCMC")
library(ggplot2)
library(reshape2)
library(dplyr)
data_rownames <- rownames(com_data)
data_colnames <- colnames(com_data)
id.var <- data_rownames
data_m <- melt(com_data,id=id.var)
data_m$idv <- seq(1, 20, by = 1)
data_m

colnames(data_m)=c("parameters","methods","std.dev","id")
data_m

p <- ggplot(data_m,aes(x=parameters,y=std.dev))
p2 <- p+geom_bar(stat = "identity",position = "dodge",aes(fill=methods))
p2+theme(legend.position="top")

###############################################################
#figure for time
#load("comparing CRE without interactive eff.RData")
com_data <- com_data <- cbind(mi_cre[6],mi_ml[6],mi_gmm[6],mi_mcmc[6])
rownames(com_data)=c("time")
colnames(com_data)=c("CRE","ML","GMM","MCMC")
library(ggplot2)
library(reshape2)
library(dplyr)
data_rownames <- rownames(com_data)
data_colnames <- colnames(com_data)
id.var <- data_rownames
data_m <- melt(com_data,id=id.var)
data_m$idv <- seq(1, 4, by = 1)
data_m

colnames(data_m)=c("computation_cost","methods","computation_time","id")
data_m

p <- ggplot(data_m,aes(x=computation_cost,y=computation_time))
p2 <- p+geom_bar(stat = "identity",position = "dodge",aes(fill=methods))
p2+theme(legend.position="top")

