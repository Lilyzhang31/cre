

#DGP: linear, one threshold, two thresholds


gen_fe <- function (t, n) {
  ai <- rnorm(n,sd=0.5)
  ef <- matrix(ai, nrow = t, ncol = n,byrow = T)
  
  efm <-  as.vector(ef)
  efm
}


gen_ft <- function (t, n) {
  f <- rnorm(t,sd=0.5)
  ef <- matrix(f, nrow = t, ncol = n,byrow = F)
  
  efm <-  as.vector(ef)
  efm
}


getmi = function(x,tt,nn){
  k = ncol(x)
  z1 = matrix(as.vector(matrix(colMeans(matrix(as.vector(x),nrow = tt)),nrow = tt,ncol = nn*k,byrow = TRUE)),nrow = tt*nn,ncol = k)
  return(z1)
}


#f_t 
getmi2 = function(x,tt,nn){
  k = ncol(x)
  z1 = matrix(as.vector(matrix(rowMeans(matrix(as.vector(x),nrow = tt)),nrow = tt,ncol = nn*k,byrow = FALSE)),nrow = tt*nn,ncol = k)
  return(z1)
}
##############################################
dgp_0th = function(t,n){
  rho1=0.3
  la1=-0.6
  a1=0.3

  
  b11 = 1
  b12 = 1

  
  t = t+1
  
  # generate data
  tt = t
  nt = n*tt
  t=tt
  ###############################################
  w = matrix(0,n,n)
  for (i in 1:n) {
    for (j in 1:n) {
      if(i<j & i> (j-4)) {w[i,j]=1}
      else {w[i,j]=0}
      
      if (i>j) {w[i,j]=w[j,i]}
    }
  }
  
  ws = rowSums(w)
  w = w/ws
  ##############################################
  #ai = rnorm(n,1)  # fixed effect

  id <- rep(1:n, each=t)
  ye <- rep(1:t, times=n)
  
  
  
  #################################################
  x <- rnorm(nt,sd=2)
  

  
  h <- kronecker(w,diag(tt))
  wx <- h%*%x
  e <- 0.5*rnorm(nt,0)
  
  ##################################
  x = as.matrix(x)
  xbar = getmi(x,t,n)
  z1 = matrix(1,nrow = n*t)
  
  wx = as.matrix(wx)
  wxbar = getmi(wx,t,n)
  wxbar = h%*%xbar
  
  xtsbar = getmi2(x,t,n)
  wxtsbar = getmi2(wx,t,n)
 
  ai = xbar+wxbar+gen_fe(t=tt,n)
  ft = xtsbar+wxtsbar+gen_ft(t=tt,n)
  #ai2 = matrix(ai,t,n)
  #ai = ai2[1,]
  intercf = cbind(xbar*xtsbar,xbar*wxtsbar,wxbar*xtsbar,wxbar*wxtsbar)
  #################################
  
  
  #y1m = b11*x + b12*h%*%x+0.5*ai+1.5*ft+intercf[,1]+intercf[,2]+intercf[,3]+intercf[,4]+e
  #################################
  
  #two-way fixed effect
  y1m = b11*x + b12*h%*%x+0.5*ai+1.5*ft+5*ai*ft+e
  #y1m = b11*x + b12*h%*%x+0.5*ai+0*ft+0*ai*ft+e
  
  y3m = matrix(y1m,t,n)
  
  
  y <- matrix(NA,t,n)
  y[1,] = rnorm(n)
  for (j in 2:t) {
    y1_1 <- y[(j-1),]
    wy1_1 <- w%*%y[(j-1),]
    y[j,] = solve(diag(n)-a1*w)%*%(rho1*y1_1+la1*wy1_1 + y3m[j,])
  }
  
  ym = y
  
  y = as.vector(ym)
  return(list(y=y,x=x,w=w,t=t,n=n,id=id,ye=ye))  
}



###############################################
dgp_without_cf = function(t,n){
  rho1=0.3
  la1=-0.6
  a1=0.3
  
  
  b11 = 1
  b12 = 1
  
  
  t = t+1
  
  # generate data
  tt = t
  nt = n*tt
  t=tt
  ###############################################
  w = matrix(0,n,n)
  for (i in 1:n) {
    for (j in 1:n) {
      if(i<j & i> (j-4)) {w[i,j]=1}
      else {w[i,j]=0}
      
      if (i>j) {w[i,j]=w[j,i]}
    }
  }
  
  ws = rowSums(w)
  w = w/ws
  ##############################################
  #ai = rnorm(n,1)  # fixed effect
  
  
  
  
  
  #################################################
  x <- rnorm(nt,sd=2)
  
  
  
  h <- kronecker(w,diag(tt))
  wx <- h%*%x
  e <- 0.5*rnorm(nt,0)
  
  ##################################
  x = as.matrix(x)
  xbar = getmi(x,t,n)
  z1 = matrix(1,nrow = n*t)
  
  wx = as.matrix(wx)
  wxbar = getmi(wx,t,n)
  
  xtsbar = getmi2(x,t,n)
  wxtsbar = getmi2(wx,t,n)
  
  ai = xbar+wxbar+gen_fe(t=tt,n)
  ft = xtsbar+wxtsbar+gen_ft(t=tt,n)
  #ai2 = matrix(ai,t,n)
  #ai = ai2[1,]

  #################################
  
  
  #y1m = b11*x + b12*h%*%x+0.5*ai+1.5*ft+intercf[,1]+intercf[,2]+intercf[,3]+intercf[,4]+e
  #################################
  
  #two-way fixed effect
  y1m = b11*x + b12*h%*%x+0.5*ai+1.5*ft+e
  
  
  y3m = matrix(y1m,t,n)
  
  
  y <- matrix(NA,t,n)
  y[1,] = rnorm(n)
  for (j in 2:t) {
    y1_1 <- y[(j-1),]
    wy1_1 <- w%*%y[(j-1),]
    y[j,] = solve(diag(n)-a1*w)%*%(rho1*y1_1+la1*wy1_1 + y3m[j,])
  }
  
  ym = y
  
  y = as.vector(ym)
  return(list(y=y,x=x,w=w,t=t,n=n))  
}


###############################################
dgp_random = function(t,n){
  rho1=0.3
  la1=-0.6
  a1=0.3
  
  
  b11 = 1
  b12 = 1
  
  
  t = t+1
  
  # generate data
  tt = t
  nt = n*tt
  t=tt
  ###############################################
  w = matrix(0,n,n)
  for (i in 1:n) {
    for (j in 1:n) {
      if(i<j & i> (j-4)) {w[i,j]=1}
      else {w[i,j]=0}
      
      if (i>j) {w[i,j]=w[j,i]}
    }
  }
  
  ws = rowSums(w)
  w = w/ws
  ##############################################
  #ai = rnorm(n,1)  # fixed effect
  
  
  
  
  
  #################################################
  x <- rnorm(nt,sd=2)
  
  
  
  h <- kronecker(w,diag(tt))
  wx <- h%*%x
  e <- 0.5*rnorm(nt,0)
  
  ##################################
  x = as.matrix(x)
  xbar = getmi(x,t,n)
  z1 = matrix(1,nrow = n*t)
  
  wx = as.matrix(wx)
  wxbar = getmi(wx,t,n)
  
  xtsbar = getmi2(x,t,n)
  wxtsbar = getmi2(wx,t,n)
  
  ai = xbar+wxbar+gen_fe(t=tt,n)
  ft = xtsbar+wxtsbar+gen_ft(t=tt,n)
  #ai2 = matrix(ai,t,n)
  #ai = ai2[1,]
  intercf = cbind(xbar*xtsbar,xbar*wxtsbar,wxbar*xtsbar,wxbar*wxtsbar)
  #################################
  
  
  #y1m = b11*x + b12*h%*%x+0.5*ai+1.5*ft+intercf[,1]+intercf[,2]+intercf[,3]+intercf[,4]+e
  #################################
  
  #two-way fixed effect
  y1m = b11*x + b12*h%*%x+e
  
  
  y3m = matrix(y1m,t,n)
  
  
  y <- matrix(NA,t,n)
  y[1,] = rnorm(n)
  for (j in 2:t) {
    y1_1 <- y[(j-1),]
    wy1_1 <- w%*%y[(j-1),]
    y[j,] = solve(diag(n)-a1*w)%*%(rho1*y1_1+la1*wy1_1 + y3m[j,])
  }
  
  ym = y
  
  y = as.vector(ym)
  return(list(y=y,x=x,w=w,t=t,n=n))  
}

