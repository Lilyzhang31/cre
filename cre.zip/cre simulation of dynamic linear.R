
rm(list=ls())
setwd("xx")
#source("dptsd_mcmc.R")
source("cre_dptsd.R")
source("cre_DGP_dynamic.R")


pt1 = proc.time()

nrep=10 #replications
estb <- matrix(rep(NA, 5 * nrep), ncol = 5)

for(rp in 1:nrep){

data = dgp_0th(t=10,n=100)
y <- data$y
x <- data$x
w <- data$w
t <- data$t
n <- data$n
tt =t
#--------------------------------
est_linear <- dpsd_linear(y,x, w,tt,n)
est_linear$blin


estb[rp,]=est_linear$blin[1:5]
}


mi1=colMeans(estb)
sd1=cbind(sd(estb[,1]),sd(estb[,2]),sd(estb[,3]),sd(estb[,4]),sd(estb[,5]))

rbind(mi1,sd1)

md=cbind(mi1[1],sd(estb[,1]),mi1[2],sd(estb[,2]),mi1[3],sd(estb[,3]),mi1[4],sd(estb[,4]),mi1[5],sd(estb[,5]))

pt2 = proc.time()

print(c(nrep,pt2[3]-pt1[3]),digits=3)
Sys.time()

sink(paste("Table 1 cer simulation results.txt"))
cat("Table 1","\n")
md
sink()